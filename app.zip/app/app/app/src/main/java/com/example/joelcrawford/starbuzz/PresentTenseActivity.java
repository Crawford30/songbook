package com.example.joelcrawford.starbuzz;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.text.Editable;
import android.text.TextWatcher;

public class PresentTenseActivity extends Activity {

    public static final String EXTRA_PRESENT_NO = "present_NO";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_present_tense );

        //get lyrics from intent

        int present_NO =(Integer) getIntent().getExtras().get( EXTRA_PRESENT_NO );
        PresentTense presentTense= PresentTense.presentTenses[present_NO];


        //populate the title
//      TextView present_title= (TextView) findViewById( R.id.present_title );
//        present_title.setText( PresentTense.getPresent_title() );


        //populate the lyrics
        TextView present_words = (TextView) findViewById( R.id.present_words );
        present_words.setText( presentTense.getPresent_words() );

    }
}
