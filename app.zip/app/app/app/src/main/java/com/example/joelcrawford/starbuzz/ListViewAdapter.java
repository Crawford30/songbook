package com.example.joelcrawford.starbuzz;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ListViewAdapter extends BaseAdapter {

    Context cont;
    LayoutInflater layinfla;
    List<Drink> drinklist;
    ArrayList<Drink> drinkarray;


    public ListViewAdapter(Context con, List<Drink> drink) {

        cont = con;
        drinklist = drink;
        this.layinfla = LayoutInflater.from( cont );
        this.drinkarray = new ArrayList<Drink>();
        this.drinkarray.addAll( drink );

        //super();
    }


    public class ViewHolder {

        TextView textView;
    }


    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public int getCount() {
        //return 0;
        return drinklist.size();
    }

    @Override
    public Drink getItem(int position) {
        //return null;
        return drinklist.get( position );
    }

    @Override
    public long getItemId(int position) {
        //return 0;

        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        final ViewHolder holder;

        if (convertView == null) {
            holder = new ViewHolder();

            convertView = layinfla.inflate( R.layout.model_item, null );
            holder.textView = (TextView) convertView.findViewById( R.id.description );
            convertView.setTag( holder );

        } else {

            holder = (ViewHolder) convertView.getTag();
        }
        holder.textView.setText( drinklist.get( position ).getDescription() );

        return convertView;
    }

    public void desFilter(String description) {

        description = description.toLowerCase( Locale.getDefault() );
        drinklist.clear();


        if (description.length() == 0) {
            drinklist.addAll( drinkarray );

        } else {

            for (Drink DL : drinkarray) {
                if (DL.getDescription().toLowerCase( Locale.getDefault() ).contains( description )) {
                    drinklist.add( DL );
                }
            }
        }
        notifyDataSetChanged();
    }
}
