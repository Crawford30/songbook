package com.example.joelcrawford.starbuzz;

import java.security.PublicKey;

public class PresentTense {


    private String present_title;
    private String present_words;

    public static final PresentTense[] presentTenses ={

            new PresentTense( "1. BE NOT ASHAMED OF JESUS.","1. BE NOT ASHAMED OF JESUS.\n\n" +
                    "\tCHORUS:\n" +
                    "\tBe not ashamed of Jesus,\n" +
                    "\tFor His promises are true,\n" +
                    "\tBe not ashamed of Jesus,\n" +
                    "\tIn the form, He’s unveiled today.\n" +
                    "\n" +

                    "I lived not within God promises in my life,\n" +
                    "World system kept me from the light,\n" +
                    "Then Jesus came, oh praise His name,\n" +
                    "Send on someone to turn on the light.\n" +
                    "\n" +

                    "No longer in sin and shame anymore,\n" +
                    "In His promises am dinning each day,\n" +
                    "The table is spread for on and all,\n" +
                    "Come dine with the eagles on high.\n" ),

            new PresentTense( "2. THE FUTURE HOME.\n","2. THE FUTURE HOME.\n\n" +
                    "There’s a future home for the earthly bride,\n" +
                    "And the heavenly Groom to dwell,\n" +
                    "It’s a city built by God on high for those who overcome,\n" +
                    "Eyes have not seen, ears have not heard all the beauties in that home,\n" +
                    "For it’s never entered into the hearts of men,\n" +
                    "What God has in store for His own.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tI could sing about heaven for all my years and never get the story told,\n" +
                    "\tOf the jasper walls and the gates of pearl and the streets made of pure gold,\n" +
                    "\tEven John the Revelator in the heavenly vision could not write all that he saw,\n" +
                    "\tI could sing about heaven for all my years yet I can not tell it all.\n" +
                    "\n" +

                    "From the throne, there flow a river of life with water crystal’s and clear,\n" +
                    "It flows by the tree of life supplying the entire city of God,\n" +
                    "And the walls of the city that hold twelve gates are built of precious stones,\n" +
                    "It’s  the heavenly home where the bride will rest from all the earthly cares.\n" ),

            new PresentTense( "3. IN CHRIST IT’S DONE.\n","3. IN CHRIST IT’S DONE.\n\n" +
                    "One of these days I’ll be carried home,\n" +
                    "Where no sorrow ever come (In Christ it’s done),\n" +
                    "In Christ it’s done, He’s taken my burdens (Troubles and Trails),\n" +
                    "Safe from debt of sin and shame,\n" +
                    "Him I give all glory and praise (And I’m now)\n" +
                    "Abiding in my Jesus (And I’m now)\n" +
                    "Entered into His rest.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\t(In Christ it’s done)In Christ it’s done, He’s taken my burdens,\n" +
                    "\t(Trouble and Trials in my life),\n" +
                    "\tYes in my life as I live for Him (As I live for Him….. daily),\n" +
                    "\tShaking hands with Jesus (And Tell),\n" +
                    "\tThe world of His Saving Power (And I’m now),\n" +
                    "\tAbiding in my Jesus (And I’m now),\n" +
                    "\tEntered into His rest.\n" +
                    "\n" +

                    "I am beholding His blessed face,\n" +
                    "And I feel His abundance grace\n" +
                    "(In Christ, it’s done) In Christ it’s done, He’s taken my burdens,\n" +
                    "(Trouble and Trials)\n" +
                    "Oh what peace and Joy sublime\n" +
                    "In His name and love divine (And I’m now)\n" +
                    "Abiding in my Jesus (And I’m now)\n" +
                    "Entered into His rest.\n" ),

            new PresentTense( "4. A HEART FILLED WITH THE SPIRIT\n","4. A HEART FILLED WITH THE SPIRIT.\n\n" +
                    "I remember standing by the bank of a river,\n" +
                    "And the tears filled my face from my heart,\n" +
                    "As my Lord held weak hand, He smiled and whispered,\n" +
                    "My child you’re going to live a life in a better way.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tAnd you’ll have eyes that will see visions,\n" +
                    "\tYou’ll have feet that will follow in my footsteps,\n" +
                    "\tYou’ll have hands that will handle My word with wisdom,\n" +
                    "\tAnd a heart that’s filled with The Spirit and a new life.\n" +
                    "\n" +

                    "I have often heard and read about salvation,\n" +
                    "How a heart that’s pricked can turn to Jesus,\n" +
                    "When it hears, believes and turn the other way,\n" +
                    "Walk held by Jesus through, His unseen Hand.\n" +
                    "\n" +

                    "Now I know that the pearly gates are open,\n" +
                    "Leading to where we’ll live with Jesus forever,\n" +
                    "There my mansion is built for my dwelling,\n" +
                    "And the streets there within are filled with gold.\n" ),

            new PresentTense( "5.THE FOUNTAIN FLOWED FOR ME.\n","5.THE FOUNTAIN FLOWED FOR ME.\n\n" +
                    "when the man of Galilee on the bad and cruel tree,\n" +
                    "He has dying sinners like me,\n" +
                    "As the Blood was dripping down,\n" +
                    "On the cross and on the ground.\n" +
                    "There was a fountain which flowed down for me.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tYes, for me and the sins of my soul\n" +
                    "\tYes, it cleansed me and made me free and whole,\n" +
                    "\tAs the Blood was dripping down\n" +
                    "\tOn the cross and on the ground\n" +
                    "\tThere was a fountain which flowed down for me.\n" +
                    "\n" +

                    "When they pierced His precious side,\n" +
                    "“Oh, forgive them” there He cried,\n" +
                    "There was pardon extended to me\n" +
                    "As the Blood and Water came, glory to His Precious Name,\n" +
                    "There was a fountain which flowed down for me.\n" ),

            new PresentTense( "6. LIVE IM GLORY BY AND BY.\n","6. LIVE IM GLORY BY AND BY.\n\n" +
                    "Men like to stay here longer, than man’s allotted days,\n" +
                    "And watch the fleeting changes, life’s uneven ways\n" +
                    "But when my Saviour calls me, I’ll abandon this evil world\n" +
                    "To live with Him forever, in glory by and by.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tOh yes to live in glory …. glory by and by,\n" +
                    "\tTo tell and sing love story … story there on high\n" +
                    "\tThere with my dear Redeemer no more to die\n" +
                    "\tOh yes to live in glory …. Glory by and by.\n" +
                    "\n" +

                    "My soul to be of service, along this pilgrim way\n" +
                    "And tell the lost about Jesus, that they be set free\n" +
                    "As day by day in the journey, lifting His banner high\n" +
                    "And live with Him forever, in glory by and by\n" +
                    "\n" +

                    "The end as told is now here, and the train is moving on\n" +
                    "To yonder home Supernal, the land of endless day\n" +
                    "So, cling to Him forever, and look beyond the sky\n" +
                    "And spend the endless ages, in glory by and by.\n" ),

            new PresentTense( "7. HOLD ON TO JESUS.\n","7. HOLD ON TO JESUS.\n\n" +
                    "\tCHORUS:\n" +
                    "\tI’m gonna hold on, hold on to Jesus,\n" +
                    "\tHold to the Lamb of Calvary\n" +
                    "\tI’m gonna hold on, hold on to Jesus,\n" +
                    "\tAnd Jesus will hold on to me.\n" +
                    "\n" +

                    "In this troubled world we live in, nothing seems to make sense,\n" +
                    "Many looking for the way, searching to and fro,\n" +
                    "Sometimes this rope I’m holding seems to be slipping,\n" +
                    "But I’m gonna hold on tighter to, the only hope I know.\n" +
                    "\n" +

                    "Old Satan keeps on talking, saying “you can’t make it”,\n" +
                    "Trying to convince me, there is no use to try,\n" +
                    "But I refuse to listen, and keep right on going,\n" +
                    "Trusting and believing in Jesus knots of time.\n" +
                    "\n" +

                    "Denormals kept on claiming, there is no need to come out,\n" +
                    "Trying to convince me that, we all serve the same God,\n" +
                    "This one went out saying, “I’d rather abide in Jesus,\n" +
                    "Where His works are proven in, both words and deed.”\n" +
                    "\n" +

                    "Old devil keeps on lying, that I won’t overcome,\n" +
                    "Diseases and afflictions, that he throws my way,\n" +
                    "But I rebuke him saying, “Get behind me Satan,\n" +
                    "My Lord and God conquered all, one day on Calvary.”\n" ),

            new PresentTense( "8. WAY DOWN DEEP\n","8. WAY DOWN DEEP.\n\n" +
                    "\tDown deep (way down deep) inside my soul,\n" +
                    "\tWhere once it was cold and dark (cold and dark)\n" +
                    "\tI feel (I can feel) Jesus loves take ahold,\n" +
                    "\tWay down deep in my heart.\n" +
                    "\n" +

                    "The highway of heartaches is rocky and rough,\n" +
                    "Lord, I learned it long time ago,\n" +
                    "You can’t build a fire from the ashes of love\n" +
                    "Roses don’t bloom in the snow.\n" +
                    "\n" +

                    "He was my light on the darkest of days,\n" +
                    "The storms then were raging within.\n" +
                    "And slowly but surely the clouds rolled away,\n" +
                    "And the sun started shinning again.\n" ),

            new PresentTense( "9. OPEN UP THEM PEARLY GATES","9. OPEN UP THEM PEARLY GATES.\n\n"+ "\tCHORUS:\n" +
                    "   Open up them pearly gates,\n " +
                    "   Open up them pearly gates\n" +
                    "   Open up them pearly gates for me \n" +
                    "   Hallelujah, ('lujah!)\n" +
                    "   When you hear that trumpet blast\n" +
                    "   I’ll be coming home at last\n" +
                    "   Open up them pearly gates for me\n" +
                    "\n" +

                    "Now listen all you sinners \n" +
                    "If you wonna get to heaven (heaven)\n" +
                    "Better get down on knees and pray\n" +
                    "And all you gambling sinners\n" +
                    "Better quit sinning else you'll be judged\n" +
                    "Get yourself prepared for that great judgment day\n" +
                    "\n" +

                    "Now often I had a vision\n" +
                    "Seen them gates are closing, closing\n" +
                    "And I saw you sinners all outside\n" +
                    "You’d better make your decision\n" +
                    "Pray that you’ll be chosen, chosen\n" +
                    "Gonna be too late  when you're done laid down and die\n" ),

            new PresentTense( "10. OLD COUNTRY CHURCH","10. OLD COUNTRY CHURCH.\n\n" +"Oh I’d like to go back\n" +
                    "To that old country church\n" +
                    "To hear the songs of praise (songs of praise)\n" +
                    "How the people would sing?\n" +
                    "It would make the rafters ring\n" +
                    "At the old (at the old) country church\n" +
                    "\n" +

                    "   Shall we gather at the river?\n" +
                    "   The beautiful the beautiful river\n" +
                    "   Gather with the saints at the river\n" +
                    "   That flows from the throne of God\n" +
                    "\n" +

                    "Oh I’ll never forget \n" +
                    "At the old country church\n" +
                    "How the glory of the Lord came down\n" +
                    "And the children would smile\n" +
                    "As they shouted down the aisle\n" +
                    "(Of the old), of the old country church\n" +
                    "\n" +

                    "   In the sweet by and by\n" +
                    "   We shall meet old that beautiful shore\n" +
                    "   In the sweet by and by\n" +
                    "   We shall meet on that beautiful shore\n" +
                    "\n" +

                    "Then on Sunday I’d see\n" +
                    "All my friends dear to me\n" +
                    "At the old country church\n" +
                    "When we’d kneel down to pray\n" +
                    "Everybody would be there\n" +
                    "(At the old), at the old country church\n" +
                    "\n" +

                    "   Leaning (leaning) leaning (I’m leaning)\n" +
                    "   Safe and secure from all alarms\n" +
                    "   Leaning (leaning) leaning (I’m leaning) \n" +
                    "   Leaning on the everlasting hand\n" +
                    "\n" +

                    "Now the years have gone by \n" +
                    "And so many have gone \n" +
                    "At the old country church\n" +
                    "But they’re on the other shore\n" +
                    "When they’ll sing forever more\n" +
                    "As they did at that old country church\n" +
                    "\n" +

                    "   I’m redeemed (oh I’m redeemed) by love divine (by love divine)\n" +
                    "   Oh glory, glory Christ is mine (Christ is mine)\n" +
                    "   All to Him (all to Him) I now resign (I now resign)\n" +
                    "   (I have been) I have been redeemed]X2\n" +
                    "   [At that old country church]\n" ),

            new PresentTense( "11. THERE’S GONNA BE A GREAT DAY", "11. THERE’S GONNA BE A GREAT DAY.\n\n" + "There’s gonna be a great day one of this morning \n" +
                    "(one of these great morning)\n" +
                    "When the Lord shall call together His own\n" +
                    "He’s gonna come back day without a great warning\n" +
                    "(without a great warning)\n" +
                    "When He comes to take us to that heavenly home\n" +
                    "\n" +

                    "   CHORUS:\n" +
                    "   There’s gonna be a great day one of this morning \n" +
                    "   When the Lord shall call together His own\n" +
                    "   So be ready always for that great day that’s coming\n" +
                    "   To go with Him and meet around the throne\n" +
                    "\n" +

                    "For all His children that are ready and watching\n" +
                    "(ready and watching)\n" +
                    "That will be a bright and beautiful day\n" +
                    "For God will take them to a home that’s waiting\n" +
                    "(home that’s waiting)\n" +
                    "And there with our dear Lord they will ever stay\n" +
                    "\n" ),

            new PresentTense( "12. WHEN HE CALLS ME, I’LL FLY AWAY","12. WHEN HE CALLS ME, I’LL FLY AWAY.\n\n" +
                    "There was once a time when in my life\n" +
                    "I was condemned to die\n" +
                    "I was walking in my sinful ways\n" +
                    "Jesus paid the ransom for my soul\n" +
                    "I’ll bid this world good bye\n" +
                    "When He calls me, I’ll fly away\n" +
                    "\n" +

                    "   CHORUS:\n" +
                    "   When He calls me, I will answer here am I \n" +
                    "   I am ready if He wants me to go\n" +
                    "   There is a mansion now awaiting me on high\n" +
                    "   And I’m going there by and by\n" +
                    "   I have made my preparation\n" +
                    "   From this world of separation\n" +
                    "   I am walking on God highway\n" +
                    "   When He calls, I’ll fly away\n" +
                    "\n" +

                    "If He needs me in His harvest\n" +
                    "Helping gather in the sheaves\n" +
                    "I will gladly, labour on, below\n" +
                    "If on earth, my work is finished\n" +
                    "And it’s time for me to leave\n" +
                    "When He calls, I will be glad to go\n" +
                    "\n" +

                    "I could never think of turning back into this world of sin,\n" +
                    "I’m rejoicing in this old true way(gospel way).\n" +
                    "I am waiting for the time when Heaven, I shall enter in,\n" +
                    "I am read should He call today.\n" ),

            new PresentTense( "13. DAYS OF ELIJAH\n","13. DAYS OF ELIJAH.\n\n" +
                    "These are the days of Elijah,\n" +
                    "Declaring the word of the Lord,\n" +
                    "And these are the days of your Servant,\n" +
                    "The prophet, of Revelation 22:9,\n" +
                    "These are the days of great victory,\n" +
                    "For the First Class Bride of the Lord,\n" +
                    "And the voice of the prophet, is still,\n" +
                    "Crying, “prepare ye the way of the Lord.”\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tBehold He’s come, veiled in Man,\n" +
                    "\tNow in Africa, like it was foretold,\n" +
                    "\tLift your voice, redemption now is here,\n" +
                    "\tOut of Zion’s hill Salvation has come.\n" + "\n" +

                    "These are the days of the end times,\n" +
                    "The Bridegroom will soon be here,\n" +
                    "The days that the Prophet spoke of,\n" +
                    "Saying, “I’ll ride this trail once again”,\n" +
                    "The message is still forerunning,\n" +
                    "The second coming of the Lord,\n" +
                    "The trumpet now has been sounded,\n" +
                    "Be ready, to meet Him up in the air.\n" ),





            new PresentTense( "14.LEAN ON JESUS.","14.LEAN ON JESUS.\n\n" + "Some-times in our lives, we all have pain,\n" +
                    "We all have sorrow;\n" +
                    "We, who are in Christ, the lord Jesus,\n" +
                    "Always the present Tense.\n" +
                    "\n" +

                    "    Lean on Jesus, when you’re not strong;\n" +
                    "    You need a friend, who can help you carry on;\n" +
                    "    And it won’t be long, when He meets your needs;\n" +
                    "    He’s worthy to lean on.\n" +
                    "\n" +

                    "Wont you please, forego your pride;\n" +
                    "He has all things, that you need to have;\n" +
                    "For, none else can fill those of your needs;\n" +
                    "That, you must have.\n" +
                    "\n" +

                    "You must call on Jesus my friend, when you need a hand;\n" +
                    "We all need somebody to lean on;\n" +
                    "For you may have a problem, you don’t understand;\n" +
                    "We all need somebody to lean on.\n" +
                    "\n" +

                    "     Lean on Jesus, when you’re not strong;\n" +
                    "     He’ll be your friend, who can help you carry on;\n" +
                    "     For, it won’t be long, till you gonna need;\n" +
                    "     Somebody to lean on.\n" +
                    "\n" +

                    "Wont you call Him on the scene, when in need indeed;\n" +
                    "We all need somebody to lean on;\n" +
                    "Call Him when you a problem, you don’t understand;\n" +
                    "We all need somebody to lean on.\n" +
                    "\n" +

                    "Where, there is a load, that you have to bear;\n" +
                    "That you can’t carry, as, you travel this road;\n" +
                    "And you need some help only call on, Jesus;\n" +
                    "\n" +

                    "(call Him)\n" +
                    "When you need a friend\n" +
                    "(call Him)\n" +
                    "Call Jesus,\n" +
                    "(call Him)\n" +
                    "When you need a friend, we all need Jesus to lean on\n" ),

            new PresentTense( "15. KNOWING THE TIME." ,"15. KNOWING THE TIME.\n\n" +
                    "Knowing the time that is now at hand,\n" +
                    "To awake, out of sleep.\n" +
                    "For now, is our redemption nearer,\n" +
                    "Than when we believed.\n" +
                    "\n" +

                    "CHORUS:\n" +
                    "    The night is far spent,  The day is here now;\n" +
                    "    Let therefore forecast all the works of darkness,\n" +
                    "    And let us rejoice, in the armor of Light;\n" +
                    "    The Lord Jesus Christ,\n" +
                    "\n" +

                    "And while in the Light,\n" +
                    "The heavenly light;\n" +
                    "Let us walk in righteousness.\n" +
                    "For behold He comes with His rewards,\n" +
                    "Every man according to his works"),

            new PresentTense( "16. THE BLOOD STILL FLOWS.\n","16. THE BLOOD STILL FLOWS.\n\n" +
                    "There’s a river of life that springs from Calvary,\n" +
                    "And it heals broken hearts and saddened souls,\n" +
                    "Jesus shed His precious blood, for you and for me,\n" +
                    "And the blood still flows, the blood still flows.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tThere is power in the blood,\n" +
                    "\tThat comes from grace and love,\n" +
                    "\tStronger than anybody knows,\n" +
                    "\tOne drop is all it takes, to give eternal life,\n" +
                    "\tAnd the blood still flows, the blood still flows.\n" +
                    "\n" +

                    "Don’t listen to the world,\n" +
                    "When they say the Saviour is gone,\n" +
                    "He lived, conquered death, rose to live again,\n" +
                    "He sits on God right hand; He is the Lord and Christ,\n" +
                    "And the blood still flows, the blood still flows.\n" ),

            new PresentTense( "17. STEP INTO THE LORD", "17. STEP INTO THE LORD.\n\n" +"\tCHORUS:\n" +
                    "\tStep into the Lord (Lord Jesus)\n" +
                    "\tInto Christ a little deeper (a little bit deeper)\n" +
                    "\tGet into His word for He is life\n" +
                    "\tStep into the Lord (Lord Jesus)\n" +
                    "\tInto Christ a little deeper (a little bit deeper)\n" +
                    "\tCome join the bride singing praises to the Lamb of God\n" +
                    "\n" +

                    "It’s time we as Christians, stand up for what is right;\n" +
                    "Its time we squared our hearts back, With His sword in our hands to fight;\n" +
                    "For the Bible is our weapon, and the spirit is our shield;\n" +
                    "For the few there be need righteousness, To be workers for the Kingdom.\n" +
                    "\n" +


                    "There is victory for the Bride, who walks this narrow way;\n" +
                    "For there is a price appointed, For the soul who doesn’t go stray\n" +
                    "Oh, I want to live for Jesus, be all that I should be,\n" +
                    "So, I can rest with Him forever live eternally.\n" ),

            new PresentTense( "18. GO DEVIL GO \n","18. GO DEVIL GO.\n\n" +
                    "I was  a hostage and taken under siege,\n" +
                    "By terrorists in the spiritual realm,\n" +
                    "But by the power of the only true God,\n" +
                    "We both were rescued from sin and shame.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tI have now regained my consciousness,\n" +
                    "\tAfter having been rescued by The Lord,\n" +
                    "\tAnd in The Name of The Lord Jesus Christ,\n" +
                    "\tI say to you now, go devil go.\n" +
                    "\n" +

                    "The vict’ry  trumpet has now been sounded,\n" +
                    "For the  enemy subdued and defeated,\n" +
                    "And through the Musick the Bride is now guarded,\n" +
                    "As I command you, go devil  go.\n" +
                    "\n" +

                    "The love that once was delivered to the saints,\n" +
                    "Through Brother Federick, was recovered for the Bride,\n" +
                    "And behold in behold the company of Brother Federick,\n" +
                    "We are united, go devil go.\n" +
                    "\n" +

                    "Ezekiel 34 is already made clear,\n" +
                    "The First Class Bride now is feeding from above,\n" +
                    "Through one shepherd in the age as always,\n" +
                    "You got to give up,  go devil go.\n" ),


            new PresentTense( "19. BWANNA YESU AKANITA"," 19. BWANA YESU AKANIITA.\n\n" +
                    "1. Duniani leo, kuna sauti nyingi.\n" +
                    "   Ambazo si za halali, zimewanasa wengi.\n" +
                    "   Lakini kati ya mangurumo, kuna moja ya kweli.\n" +
                    "   Itamkayo msamaha, yatoka Kalvari.\n" +
                    "\n" +
                    "        CHORUS\n" +
                    "        Bwana Yesu akaniita,\n" +
                    "        Pale msalabani,\n" +
                    "        Ndipo hapo nikajua kwamba,\n" +
                    "        Yesu Ndiye Mwito Mkuu.\n" +
                    "        \n" +
                    "2.  Walipokuwa wanamtesa, nakumkejeli, \n" +
                    "    Aliniita kwa neema,nami nikaitika, \n" +
                    "    Hawakujua mimi Naye, tulitia mkataba, \n" +
                    "    Wa ondoleo la dhambi, akasema yameisha. \n" +
                    "\n" +

                    "3.  Hata leo yuaitana, walio wake waje juu, \n" +
                    "    Wafikie ukamilifu, wa mpango wa ukombozi,\n" +
                    "    Wakigeuka na kutubu, watazame Kalvari, \n" +
                    "    Watafunuliwa ya kwamba, Yesu Ndiye Mwito Mkuu\n" +
                    "\n" +


                    "***************************************************\n" +
                    "       (ENGLISH TRANSLATION.)\n" +
                    "       19. THE LORD JESUS CALLED ME.\n\n" +
                    "1.  In the world, today there are many voices,\n" +
                    "    That are not genuine and many have been trapped\n" +
                    "    Amidst these there is a true voice\n" +
                    "    Which speaks pardon from Calvary.\n" +
                    "\n" +
                    "                      CHORUS:\n" +
                    "                      The Lord Jesus called me there at the cross,\n" +
                    "                      And it’s there I knew that\n" +
                    "                      Jesus is The Great calling.\n" +
                    "\n" +
                    "2.  When they were torturing and mocking Him,\n" +
                    "    He called me by His grace and I answered\n" +
                    "    They didn’t know that me and Him signed a contract\n" +
                    "    For the remission of sin and He said, it’s finished.\n" +
                    "\n" +

                    "3.  Even today He is calling those that are His to come up high,\n" +
                    "    To get perfected in the Redemption plan\n" +
                    "    If they turn and repent and look away to Calvary\n" +
                    "    It will be revealed to them that Jesus is \n" +
                    "    The Great Calling.\n" +
                    "\n" ),

            new PresentTense( "20. SIKU YA PUMZIKO","20. SIKU YA PUMZIKO.\n\n" +
                    "\n" +
                    "1.  Ninajua kuna siku sitalia,\n" +
                    "     Siku sitachomwa,\n" +
                    "     Ninajua kuna siku imewekwa,\n" +
                    "     Siku ya pumziko.\n" +
                    "\n" +

                    "          CHORUS:\n" +
                    "          Sitalia, sitachomwa ni furaha, ( tele)\n" +
                    "          Mimi sitalia.\n" +
                    "          Sitalia, sitachomwa ni furaha, ( tele)\n" +
                    "          Mimi sitalia.\n" +
                    "\n" +

                    "2.  Ninajua Bwana Yesu, ameiweka, ( siku),\n" +
                    "     Siku ya pumziko,\n" +
                    "     Kwa wateule wale wote wameishi,\n" +
                    "     Maisha matakatifu.\n" +
                    "\n" +
                    "3.  Kwa damu Yake Bwana Yesu,\n" +
                    "     Nemeoshwa, (mimi) niwe mtakatifu,\n" +
                    "     Si kwa nguvu zangu mimi\n" +
                    "     Hata kamwe,(kweli) ila ni kwa neema.\n" +
                    "\n" +
                    "4.  Wakichomwa wale wote\n" +
                    "     Wamemkana, (Yesu) Mimi sitalia,\n" +
                    "     Uokoke uepuke huo moto,\n" +
                    "     Mimi sitalia\n" + "\n" +

                    "***************************************************\n" +
                    "   (ENGLISH TRANSLATION.)\n" +
                    "       20.A DAY OF REST.\n\n" +
                    "\n" +
                    "1. I know there is a day I won’t cry\n" +
                    "    A day I won’t be burnt\n" +
                    "    I know there remaineth a day\n" +
                    "    A day of rest.\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tI wont cry nor be burnt but joyful\n" +
                    "\tI wont cry nor be burnt but joyful.\n" +
                    "\n" +

                    "2. I know the Lord Jesus has set a day\n" +
                    "   A day of rest\n" +
                    "   For those predestinated to live\n" +
                    "   A righteous life.\n" +
                    "\n" +

                    "3.By the Blood of the Lord Jesus\n" +
                    "   I have been washed to be righteous\n" +
                    "   Not by my own will at all but by His Grace.\n" +
                    "\n" +

                    "4. When all those who have denied Jesus\n" +
                    "    Will be burnt, I won’t cry\n" +
                    "    Believe and be saved from Hell fire\n" +
                    "    I won’t cry.\n" ),

            new PresentTense( "21. JIFICHE KWA MSALABA","21. JIFICHE KWA MSALABA.\n\n" +
                    "\n" +
                    "1. Kuna mitego mingi aina mbalimbali,\n" +
                    "   Yakuvunja mioyo, ya wale wateule,\n" +
                    "   Wake Bwana Yesu sasa Aliyewakomboa,\n" +
                    "   Kwa damu Yake Yesu – Kalvari.\n" +
                    "\n" +
                    "\tCHORUS:\n" +
                    "\tToka kwa mitego x 3\n" +
                    "\tUsinaswe\n" +
                    "\tUsinaswe x3 \n" +
                    "\tToka kwa mitego.\n" +
                    "\n" +
                    "2. Kimbia ndugu yango,\n" +
                    "   Kwa Bwana Yesu sasa,\n" +
                    "   Usikawie tena kuna mitego mingi.\n" +
                    "\n" +

                    "3. Sikia sauti Yake Aliyoiteuwa,\n" +
                    "   Sauti Yake kweli,\n" +
                    "   Upate usalama.\n" +
                    "\n" +

                    "4. Njooni sasa zote,\n" +
                    "   Twende kwa Bwana Yesu,\n" +
                    "   Hapo Msalabani,\n" +
                    "   Afiche sisi zote.\n" + "\n" +


                    " *********************************************\n" +
                    "          (ENGLISH TRANSLATION)\n" +
                    "           21. HIDE AT THE CROSS.\n\n" +
                    "\n" +
                    "1. There are many different traps,\n" +
                    "    Meant to break the hearts of believers\n" +
                    "    Those that Jesus has saved\n" +
                    "    By the Blood of Jesus at Calvary.\n" +
                    "\n" +
                    "\tCHORUS:\n" +
                    "\t(Get out of these traps) x 3\n" +
                    "\tDon’t be ensnared\n" +
                    "\t(Don’t be ensnared) x 3\n" +
                    "\tGet out of these traps.\n" +
                    "\n" +
                    "2. Run fast my brother,\n" +
                    "   To the Lord Jesus  now,\n" +
                    "   Don’t delay again, there are lots of snares.\n" +
                    "\n" +
                    "3. Hear His voice that He chose,\n" +
                    "   His True voice\n" +
                    "   You’ll be safe.\n" +
                    "\n" +
                    "4. Come ye all\n" +
                    "   Let’s go to the Lord Jesus Christ,\n" +
                    "   There at the Cross \n" +
                    "   He will hide us all." ),

            new PresentTense( "22. NAISHIA YESU","22. NAISHIA YESU.\n\n" +
                    "\n" +
                    "1. Sitangatangi Yesu, ulimwengu kamwe,\n" +
                    "    Naishia Yesu, kwa ufunuo wake,\n" +
                    "    Makundi yote, nimeyatupa sasa,\n" +
                    "    Naishia Yesu, maishani mwangu.\n" +
                    "\n" +
                    "\tCHORUS:\n" +
                    "\tNaishia Yesu, namwamini sasa,\n" +
                    "\tSina udini, maishani mwangu,\n" +
                    "\tAmefunua, Neno Lake kwangu,\n" +
                    "\tNaishia Yesu, maishani mwangu.\n" +
                    "\n" +
                    "2. Usiningoje, mimi sitarudi,\n" +
                    "    Kwa kundi lenu, kubwa ama ndogo\n" +
                    "    Nimeamua, kumulishia Yesu,\n" +
                    "    Kuishia Yesu, maishani mwangu.\n" +
                    "\n" +
                    "3. Yesu amekua, kimbilio langu,\n" +
                    "    Njoo uamue, tukimbillie Yesu,\n" +
                    "    Na sasa zote, tumuishie Yesu,\n" +
                    "   Tuishie Yesu, maishani mwetu.\n" +
                    "\n" +
                    "************************************\n" +
                    "   (ENGLISH TRANSLATION)\n" +
                    "   22.I LIVE FOR JESUS.\n\n" +
                    "\n" +
                    "1. I do not roam the world at all,\n" +
                    "    I live for Jesus by His Revelation,\n" +
                    "    I have abandoned all the groups now,\n" +
                    "    I live for Jesus throughout my life.\n" +
                    "\n" +
                    "\tCHORUS:\n" +
                    "\tI live for Jesus, I believe Him now,\n" +
                    "\tI don’t have religion in my life,\n" +
                    "\tHe has revealed His word to me\n" +
                    "\tI live for Jesus throughout my life.\n" +
                    "\n" +
                    "2. Don’t wait for me, I won’t go back\n" +
                    "    To your group, big or small,\n" +
                    "    I have decided to live for Jesus,\n" +
                    "    To live for Jesus throughout my life.\n" +
                    "\n" +
                    "3. Jesus has become my solace,\n" +
                    "    Come decide, we run to Jesus,\n" +
                    "   And now all of us live for Jesus,\n" +
                    "   We live for Jesus throughout our life.\n" ),

            new PresentTense( "23. NADANGANYWA NA SIKUBALI.","23. NADANGANYWA NA SIKUBALI.\n\n" +
                    "\n" +
                    "1. Nadanganywa, na sauti nyingi,\n" +
                    "    Nasikubali, masauti mengi,\n" +
                    "    Nimejipeana, kwa sauti moja,\n" +
                    "   Sauti ya Yesu, inanitosha.\n" +
                    "\n" +
                    "2. Usikubali, masauti mengi,\n" +
                    "    Sauti ya Yesu, maishani mwako,\n" +
                    "    Mwalike Yesu, maishani mwako,\n" +
                    "   Akufunilie, sauti ya kweli.\n" +
                    "\n" +
                    "3. Turukeruke, tumtembelee,\n" +
                    "    Tumfurahie, huyu Bwana Yesu,\n" +
                    "    Kwake Mbinguni, Ametuandalia,\n" +
                    "    Chakula nzuri, tena yakutosha.\n" +
                    "\n" +
                    "4. Njoo ndugu na dada, tule na wewe,\n" +
                    "    Meza ya Yesu, imeandaliwa,\n" +
                    "    Imeandaliwa, chakula nzuri\n" +
                    "   Chakula nzuri, ten yakutosha.\n" +
                    "\n" +
                    "***************************************\n" +
                    "      (ENGLISH TRANSLATION)\n" +
                    "      23. I REFUSED TO BE DECEIVED.\n\n" +
                    "\n" +
                    "1. I am deceived by many voices\n" +
                    "   But I have refused many voices;\n" +
                    "   I have given my own to one voice;\n" +
                    "   The Voice of Jesus is enough for me.\n" +
                    "\n" +
                    "2. Don’t accept many voices,\n" +
                    "    The voice of Jesus is enough for you,\n" +
                    "    Invite Jesus in your life,\n" +
                    "    To reveal to you His true voice.\n" +
                    "\n" +
                    "3. Let us jump and visit Him,\n" +
                    "    Let’s rejoice for the Lord Jesus,\n" +
                    "    In Heaven He has prepared\n" +
                    "    Good food that’s enough.\n" +
                    "\n" +
                    "4. come brother and sister, let’s dine together,\n" +
                    "    Jesus table is spread\n" +
                    "   Ready with good food,\n" +
                    "   Good food that’s enough.\n" ),

            new PresentTense( "24. MATENGANO","24. MATENGANO.\n\n" +
                    "\n" +
                    "1. Matengano, ni matengano,\n" +
                    "   Ni matengano sasa\n" +
                    "   Ni matengano x3 sasa.\n" +
                    "\n" +
                    "2. Umefika wakati mwema\n" +
                    "   Wakutengana na madhehebu\n" +
                    "   Ni matengano x 3 sasa.\n" +
                    "\n" +
                    "3.  Umefika wakati mwema\n" +
                    "    Wakumwamini mjumbe Branham\n" +
                    "    Ni matengano x 3 sasa.\n" +
                    "\n" +
                    "4.  Umefika wakati mwema\n" +
                    "    Wakutengana nazo dhambi\n" +
                    "    Ni matengano x 3 sasa.\n" +
                    "\n" +
                    "5.  Umefika wakati mwema\n" +
                    "    Wakutengana na dini zote\n" +
                    "    Ni matengano x 3 sasa.\n" +
                    "\n" +
                    "6. Umefika wakati mwema\n" +
                    "   Wakutengana na wenya dhambi\n" +
                    "   Ni matengano x 3 sasa.\n" +
                    "\n" +
                    "*********************************\n" +
                    "      (ENGLISH TRANSLATION)\n" +
                    "       24. SEPERATE YOURSELF.\n\n" +
                    "\n" +
                    "It is time to separate yourself completely.\n" +
                    "\n" +
                    "We have come to the right time to,\n" +
                    "separate ourselves from denominations.\n" +
                    "\n" +
                    "We have to the right time to \n" +
                    "believe Brother Branham and,\n" +
                    "separate ourselves from the world.\n" +
                    "\n" +
                    "We have come  to the right time to \n" +
                    "separate ourselves from sin.\n" +
                    "\n" +
                    "We have come to the right time to\n" +
                    "separate ourselves from  the\n" +
                    "denormals completely.\n" ),

            new PresentTense( "25. WAMEPATA YESU","25. WAMEPATA YESU.\n\n" +
                    "\n" +
                    "1. Hawa ndio wanapenda Ukweli\n" +
                    "   Wamemwamini Yesu,\n" +
                    "   Wakapata Ujumbe.\n" +
                    "\n" +
                    "2. Wakaamini Neno,\n" +
                    "   Wakapata Nabii,\n" +
                    "   Wakasonga mbele,\n" +
                    "   Wakapata Mwito.\n" +
                    "\n" +
                    "3. Hawa ndio wamepata Yesu,\n" +
                    "   Akawakubali na kuwasamehe,\n" +
                    "   Wakajazwa upendo,\n" +
                    "   Wakajazwa furaha,\n" +
                    "   Wanamsifu Yesu na kurukaruka.\n" +
                    "\n" +
                    "**********************************\n" +
                    "          (ENGLISH TRANSLATION)\n" +
                    "       25. THEY HAVE RECEIVED JESUS.\n\n" +
                    "\n" +
                    "1.  These are the one who received\n" +
                    "    the truth, believed Jesus and\n" +
                    "    received the Message.\n" +
                    "\n" +
                    "2.  They believed the word.\n" +
                    "    Received His prophet, and moved\n" +
                    "    on to receive The Great calling.\n" +
                    "\n" +
                    "3.  These are the ones that received,\n" +
                    "    Jesus, and Jesus accepted and forgive them.\n" +
                    "    They have been filled with Love and Joy,\n" +
                    "    They are praising the Lord and jumping.\n" ),

            new PresentTense( "26. UPENDE USIPENDE.","26. UPENDE USIPENDE.\n\n" +
                    "\n" +
                    "1.  Upende usipende, Yesu ni Bwana,\n" +
                    "    Upende usipende, Yesu ni Neno,\n" +
                    "    Upende usipende, Neno ni Mwito,\n" +
                    "    Amini ukombolewe.\n" +
                    "\n" +
                    "2. Upende usipende, Yesu ni njia,\n" +
                    "   Upende usipende, Yeye ni Nuru,\n" +
                    "   Upende usipende, Ndiye Neno,\n" +
                    "   Amini ukombolewe.\n" +
                    "\n" +
                    "3.  Upende usipende, dini ni tita,\n" +
                    "    Upende usipende, tita ni kifo\n" +
                    "    Upende usipende, lazima utoke,\n" +
                    "    Amini ukombolewe.\n" +
                    "\n" +
                    "********************************************\n" +
                    "   (ENGLISH TRANSLATION)\n" +
                    "   26. LIKE IT OR NOT.\n\n" +
                    "\n" +
                    "1.  You like it or not, Jesus is Lord,\n" +
                    "    You like it or not, Jesus is the word,\n" +
                    "    You like it or not, The word is the calling,\n" +
                    "    Believe and be set free.\n" +
                    "\n" +
                    "2.   You like it or not, Jesus is the way,\n" +
                    "     You like it or not, He is the light.\n" +
                    "     You like it or not, He is the word.\n" +
                    "     Believe and be set free.\n" +
                    "\n" +
                    "3.   You like it or not, denormal is a bundle\n" +
                    "     You like it or not, bundle is death,\n" +
                    "     You like it or not, you must get out.\n" +
                    "     Believe and be set free.\n" ),

            new PresentTense( "27. NJOO TWENDE KWA  YESU","27. NJOO TWENDE KWA  YESU.\n\n" +
                    "\n" +
                    "1.   Njoo njoo twende kwa Yesu,\n" +
                    "     Njoo tumwamini Yesu,\n" +
                    "     Njoo njoo twende kwa Yesu,\n" +
                    "     Hivi sasa.\n" +
                    "\n" +
                    "2.  Njoo tumwamini Yesu,\n" +
                    "    Njoo tumfurahie Yesu,\n" +
                    "    Njoo tumwimbie Yesu,\n" +
                    "    Hata sasa.\n" +
                    "\n" +
                    "3.  Njoo akufanye huru,\n" +
                    "    Njoo akufanye mshindi,\n" +
                    "    Njoo umwamini Mwito,\n" +
                    "    Hivi sasa.\n" +
                    "\n" +
                    "     (ENGLISH TRANSLATION)\n" +
                    "  27. COME LET’S GO TO JESUS.\n\n" +
                    "\n" +
                    "1.  Come come let’s go to Jesu,\n" +
                    "    Come let’s  believe Jesus,\n" +
                    "    Come come let’s go to Jesu,\n" +
                    "    Come right now.\n" +
                    "\n" +
                    "2.   Come let’s  believe Jesus,\n" +
                    "     Come let’s be happy for Jesus,\n" +
                    "     Come let’s sing for Jesus,\n" +
                    "     Come even now.\n" +
                    "\n" +
                    "3.   Come He will make you free,\n" +
                    "     Come He will make you the victor,\n" +
                    "     Come and believe the Calling,\n" +
                    "     Come right now\n" ),


            new PresentTense( "28. NISIZUIWE KUMUONA YESU.","28. NISIZUIWE KUMUONA YESU.\n\n" +
                    "\n" +
                    "1.   Nsizuiwe, kumuona Yesu,\n" +
                    "      Nakanya watu, watu, waume wote,\n" +
                    "      Nisizuiwe, kumuona Yesu. X 2.\n" +
                    "\n" +
                    "2.   Nisizuiwe kumwona Yesu,\n" +
                    "      Nisizuiwe Kusema naye,\n" +
                    "      Nataka sana, kutubu sasa,\n" +
                    "      Nisamehewe na Bwana Yesu.\n" +
                    "\n" +
                    "3.   Nisizuiwe, kupata yesu,\n" +
                    "      Naomba sasa, nipate Roho,\n" +
                    "      Roho wa Yesu, Mtakatifu. X 2\n" +
                    "\n" +
                    "4.   Nipe nafasi, nimuone pekee,\n" +
                    "      Nisilipishwe, nipewe bure,\n" +
                    "      Nipishe njia, bila kupingwa,\n" +
                    "      Bila kupingw, na wahubiri.\n" +
                    "\n" +
                    "**********************************\n" +
                    "        (ENGLISH TRANSLATION)\n" +
                    "   28. DON’T HINDER ME FROM SEEING JESUS.\n\n" +
                    "\n" +
                    "1. Don’t hinder me, for I want to see Jesus,\n" +
                    "    I want all people, specifically men.\n" +
                    "    Don’t hinder, me from seeing Jesus.\n" +
                    "\n" +
                    "2. Don’t hinder, me from seeing Jesus,\n" +
                    "    Don’t hinder from talking to Him,\n" +
                    "    I want so much to repent now.\n" +
                    "    And be forgiven by The Lord Jesus Christ.\n" +
                    "\n" +
                    "3. Don’t hinder me from receiving Jesus,\n" +
                    "    I pray now, that I get the Spirit.\n" +
                    "    The Spirit of Jesus, which is Holy.\n" +
                    "\n" +
                    "4. Give me way, I want to see Him alone,\n" +
                    "    I will not pay any fee, give it free.\n" +
                    "    Give way, without hindrance,\n" +
                    "    Without any hindrance specifically from the preachers." ),

            new PresentTense( "29. USIJITENGE NA MWITO","29. USIJITENGE NA MWITO.\n\n" +
                    "\n" +
                    "1. Usijitenge na wana wa Mwito,\n" +
                    "    Kisha useme umeonewa,\n" +
                    "    Ukijiunga na dunia,\n" +
                    "    Basi ujue umepotea. \n" +
                    "    Ukijiunga na dunia,\n" +
                    "    Basi ujue umepotea.\n" +
                    "\n" +
                    "\n" +
                    "2. Usijitenge na Yesu Kristo,\n" +
                    "    Kwani Yesu ndiye njia,\n" +
                    "    Lazima  sasa umpate Yesu,\n" +
                    "    Kwani Yesu ni Mwokozi.\n" +
                    "    Lazima  sasa umpate Yesu,\n" +
                    "    Kwani Yesu ni Mwokozi.\n" +
                    "\n" +
                    "3. Usijitenge na Neno la Mungu,\n" +
                    "    Kisha useme una kundi,\n" +
                    "    Hakun kundi lililosafi,\n" +
                    "    Ila lile ameliita.\n" +
                    "    Hakun kundi lililosafi,\n" +
                    "    Ila lile ameliita.\n" +
                    "\n" +
                    "\n" +
                    "      ******************************\n" +
                    "      (ENGLISH TRANSLATION)\n" +
                    "29. DON’T SEPARATE FROM THE CALLING.\n\n" +
                    "\n" +
                    "1. Don’t separate from the people of the calling,\n" +
                    "    Then say they are against me,\n" +
                    "    If you join the world,\n" +
                    "    Then Know you are lost.\n" +
                    "\n" +
                    "2.  Don’t separate from Jesus  Christ,\n" +
                    "     Because Jesus is the way,\n" +
                    "     You must not get Jesus.\n" +
                    "     Because Jesus is the Saviour.\n" +
                    "\n" +
                    "3. Don’t separate from the word of God,\n" +
                    "    Then say you have a group,\n" +
                    "    There is no group that is clean.\n" +
                    "    Other than the one He has called.\n" ),

            new PresentTense( "30. AMENIITA NIKAITIKA", "30. AMENIITA NIKAITIKA.\n\n" +
                    "\n" +
                    "1. Ameniita nikaitika,\n" +
                    "   Ameniokoa nikaokoka,\n" +
                    "   Ameniponya  nikapona,\n" +
                    "   Asante Bwana Yesu.\n" +
                    "\n" +
                    "2. Anakuita we itikia,\n" +
                    "   Anakupenda uokoke,\n" +
                    "   Ukiokoka utapona,\n" +
                    "   Mwitike Bwana Yesu.\n" +
                    "\n" +
                    "3. Ukiita tutaenda,\n" +
                    "    Kuwa na Yesu juu mbinguni,\n" +
                    "    Usikubali kusalia,\n" +
                    "    Haapa duniani.\n" +
                    "\n" +
                    "*************************************\n" +
                    "       (ENGLISH TRANSLATION)\n" +
                    "    30. HE CALLED ME AND I ANSWERED.\n\n" +
                    "\n" +
                    "1. He has called me and I answered,\n" +
                    "    He has saved me and I got save\n" +
                    "    He has healed me and I got healed.\n" +
                    "    Thank you Lord Jesus.\n" +
                    "\n" +
                    "2. He is calling you, You answer,\n" +
                    "    He loved you to get saved,\n" +
                    "    If you get saved you will be healed,\n" +
                    "    Answer the Lord Jesus.\n" +
                    "\n" +
                    "3. If you answer, we will go.\n" +
                    "    To be with Jesus up in Heaven.\n" +
                    "    Do not agree to be left,\n" +
                    "   Here on earth.\n" ),

            new PresentTense( "31. NJIA NI YESU.","31. NJIA NI YESU.\n\n" +
                    "\n" +
                    "1.Nimepata njia ni Yesu,\n" +
                    "   Njia hiyo ni upendo,\n" +
                    "   Nipende tuvute pamoja,\n" +
                    "   Yesu ndiye upendo.\n" +
                    "   \n" +
                    "2. Nakwalika twende kwa Yesu,\n" +
                    "    Kwenye furaha, upendo\n" +
                    "   Twende twende ndugu yangu\n" +
                    "   Kwenye furaha, upendo.\n" +
                    "\n" +
                    "3.  Tuvute tuvute pamoja,\n" +
                    "     Waliolemewa na dunia\n" +
                    "    Tuvute tulete kwa yesu,\n" +
                    "    Mwenye furaha, upendo.\n" +
                    "\n" +
                    "***********************************\n" +
                    "(ENGLISH TRANSLATION)\n" +
                    "31. PULL PULL TOGETHER.\n\n" +
                    "\n" +
                    "1. I have found that Jesus is the way,\n" +
                    "    And that way is Love\n" +
                    "    You should love me so that we\n" +
                    "    pull together, because\n" +
                    "    Jesus is love.\n" +
                    "\n" +
                    "2. I invite you to go together to  Jesus,\n" +
                    "    Where there is Joy and Love,\n" +
                    "    Let us go my friend,\n" +
                    "    Where there is Joy and Love.\n" +
                    "\n" +
                    "3.  Let us pull together\n" +
                    "     All those that are stuck in the world,\n" +
                    "     Invite and pull them to Jesus\n" +
                    "     Who gives joy and love" ),

            new PresentTense( "32. NIMEPATA YESU" ,"32. NIMEPATA YESU.\n\n" +
                    "\n" +
                    "1. Nimepata Yesu,\n" +
                    "    Nimepata neno,\n" +
                    "    Nimepata ufunuo,\n" +
                    "    Nakupata Yesu,\n" +
                    "    nikupata Neno\n" +
                    "    Asante Bwana Yesu.\n" +
                    "\n" +
                    "2. Nina Bibilia, nina sauti Yake,\n" +
                    "    Mimi ni…. Metosheka,\n" +
                    "    Nmepata Roho,\n" +
                    "    nimekuwa wake,\n" +
                    "   Asante Bwana Yesu.\n" +
                    "\n" +
                    "\n" +
                    "3. Numetoka dini,\n" +
                    "    Nikaenda kwa Yesu,\n" +
                    "    Meza yake, I tayari,\n" +
                    "    Njoo ule kwa Yesu,\n" +
                    "    Njoo ushibe kwa Yesu,\n" +
                    "   Anakungoja Bwana Yesu.\n" +
                    "\n" +
                    "****************************\n" +
                    "(ENGLISH TRANSLATION)\n" +
                    "32. I WILL STAY ON MY KNEES.\n\n" +
                    "\n" +
                    "1. I got Jesus in me, and that the way I found the word,\n" +
                    "    And getting the word, I got revelation,\n" +
                    "    Finding Jesus, is finding His word,\n" +
                    "    I thank you Lord Jesus.\n" +
                    "\n" +
                    "2. I have my Bible, I know His voice,\n" +
                    "    And thus am satisfied,\n" +
                    "    I have the Holy spirit, and have become His,\n" +
                    "    I thank you Lord Jesus.\n" +
                    "\n" +
                    "3. I have come out of denominations,\n" +
                    "    And gone into Jesus,\n" +
                    "    Where the table is spread\n" +
                    "    Come and dine with Jesus, come and be satisfied,\n" +
                    "    Jesus is waiting for you."),

            new PresentTense( "33. MCHUNGAJI MWEMA.","33. MCHUNGAJI MWEMA.\n\n" +
                    "\n" +
                    "1.  Twahitaji mchungaji mwema,\n" +
                    "     Mchungaji mjasiri,\n" +
                    "     Mchungaji wa kondoo,\n" +
                    "     Aliye na upendo.\n" +
                    "\n" +
                    "2. Wengi walio kama mimi,\n" +
                    "   Tumekuwa  nao wachungaji,\n" +
                    "   Bila kusoma Ezekieli,\n" +
                    "   Thelathini na Nne.\n" +
                    "\n" +
                    "\n" +
                    "3. Nimeanza kuisoma sasa,\n" +
                    "    Bibilia yangu sana,\n" +
                    "    Na kweli sasa haina vumbi\n" +
                    "    Mchungaji ni Yesu.\n" +
                    "\n" +
                    "**************************\n" +
                    "        (ENGLISH TRANSLATION)\n" +
                    "33. THE GREAT CALLING IS MY WATCHMAN.\n\n" +
                    "\n" +
                    "1. We need a good shepherd,\n" +
                    "    A shepherd who is brave,\n" +
                    "    A shepherd of His sheep,\n" +
                    "    One filled with Love.\n" +
                    "\n" +
                    "2. Many like me,\n" +
                    "   Have had shepherds, \n" +
                    "   Without reading Ezekiel\n" +
                    "   Thirty four[34].\n" +
                    "\n" +
                    "3. I have started reading it now,\n" +
                    "   Reading my Bible so much,\n" +
                    "   And surely now it has no dust,\n" +
                    "   And that way I know that the shepherd is Jesus." ),

            new PresentTense( "34. JIPEANE  KWA YESU","34. JIPEANE  KWA YESU.\n\n" +
                    "\n" +
                    "1. Jipeane kwa Bwana Yesu,\n" +
                    "    Umtegemee peke yake,\n" +
                    "    Uongozi mwachie\n" +
                    "    Yesu, peke Yake.\n" +
                    "\n" +
                    "2. Mambo yote uyatendayo,\n" +
                    "    Kwa eon na vito,\n" +
                    "    Yatimize kwa jina Lake,\n" +
                    "   Jina, Yesu Kristo.\n" +
                    "\n" +
                    "3. Ingia ndani ya Bwana  Yesu,\n" +
                    "   Naye Yesu ndani yako,\n" +
                    "   Na utapata ukiuliza,\n" +
                    "   Bora tu umwamini.\n" +
                    "\n" +
                    "**************************\n" +
                    "   (ENGLISH TRANSLATION)\n" +
                    "  34.  STAY NEUTRAL.\n\n" +
                    "\n" +
                    "1. Surrender yourself to the Lord Jesus,\n" +
                    "    And rely on Him alone,\n" +
                    "   Let Him take full control,\n" +
                    "   Jesus alone.\n" +
                    "\n" +
                    "2. Everything that you do,\n" +
                    "    Both in word and deed,\n" +
                    "    Do it in His name.\n" +
                    "   The name, Jesus Christ.\n" +
                    "\n" +
                    "3. Let Jesus abide in you,\n" +
                    "    And you abide in Him,\n" +
                    "   That way, ask Him for whatever you will,\n" +
                    "    And only Belive.\n" ),








            new PresentTense( "35. IT’S DIFFERENT NOW","35. IT’S DIFFERENT NOW.\n\n" + "Once I was lost in sin, I had no peace within\n" +
                    "To save my weary soul I know not how\n" +
                    "But Jesus came to me’ and by His grace I’m free\n" +
                    "Now it’s different, (yes, it’s) so different now\n" + "\n" +

                    "   CHORUS:\n" +
                    "   It’s different now, since Jesus saved my soul\n" +
                    "   It’s different now, since by His blood I’m whole\n" +
                    "   Old Satan had to flee when Jesus rescued me\n" +
                    "   Now it’s different, O so different now\n" +
                    "\n" +

                    "I went to church one day to hear them sing and pray\n" +
                    "The preacher firmly plowed the gospel plow\n" +
                    "He said you must repent, so down the aisle I went\n" +
                    "Now it’s different, (yes, it’s) so different now\n" +
                    "\n" +

                    "Sin fetters held me fast, the dye was almost cast \n" +
                    "My proud and haughty spirit would not bow\n" +
                    "But just one glimpse of Him, it broke the power of sin\n" +
                    "Now it’s different, (yes, it’s) so different now\n" +
                    "\n" +

                    "And now my hopes are bright, I praise Him day and night \n" +
                    "How He could change so I know not how\n" +
                    "But praise the Lord it’s done, the victory now  is won\n" +
                    "Now it’s different, (yes, it’s) so different now\n" ),

            new PresentTense( "36. IN-THE SLOW MOVING TRAIN.", "36. IN-THE SLOW MOVING TRAIN.\n" +
                    "\n" +
                    "I'm in the slow-moving train, bound for glory(bound for glory);\n" +
                    "Where there’s peace, Joy and Love, evermore (hallelujah);\n" +
                    "As my heart, follow His steps, and His Musick (heavenly musick),\n" +
                    "Waiting for one and all, He sayeth “come.”\n" +
                    "Having heard, of His message, fight a good fight ( In Great calling);\n" +
                    "There’s home for,  over-comers stay (yes in glory-land)\n" +
                    "By His pardon, you’re free, no more sorrows (no more tears);\n" +
                    "Believers got,  Joy and love, in their hearts to stay.\n" +
                    "\n" +

                    "Now the way to the heavenly Home, in glory (in glory);\n" +
                    "Is a straight, narrow one, to eternity(home eternal);\n" +
                    "Temptations, may cause you, to stumble(they’ll soon be over);\n" +
                    "A crown of thorns, I may wear, but I’ll reach the throne.\n" +
                    "For the streets,  of that Home, are pure gold(there is my rest);\n" +
                    "Precious souls, do not go far, astray (into darkness);\n" +
                    "Pray to God everyday, and you’ll win it(heavenly mansion);\n" +
                    "Peaceful eternity’s my destiny.\n" +
                    "\n" +

                    "There we’ll sing, there we’ll praise, and adore Him(and adore Him);\n" +
                    "While, beholding His face, in that rest(rest in glory);\n" +
                    "No more grieving, no more paining, all is gain(yes all is gain);\n" +
                    "shinning crown, we’ll receive, from our Lord.\n" +
                    "Satan won’t have a chance to deceive me (his schemes over);\n" +
                    "Now he can’t make me believe,  am wrong(never ever);\n" +
                    "Come and follow Christ, the crucified one(up to glory);\n" +
                    "Victory’s yours,  with Him, on your side.\n" ),

            new PresentTense( "37. WHEN  MY SOUL REACHES HOME."," WHEN  MY SOUL REACHES HOME.\n\n" +
                    "\n" +
                    "Since I’ve heard about, the heavenly home,\n" +
                    "In my soul, I’m resolved to leave this world (to leave this world)\n" +
                    "Soon caught away, to heavenly places, on that bright morn.\n" +
                    "A rest awaits, my soul beyond, the pearly gate(the pearly gate).\n" +
                    "\n" +

                    "\tCHORUS:\n" +
                    "\tMy soul will reach home,\n" +
                    "\tOh praise the Lord,\n" +
                    "\tRiding in the slow moving, train, to Beulah\n" +
                    "\t(to Beulah Land)\n" +
                    "\tNever again, In the old world\n" +
                    "\tAround the throne\n" +
                    "\tWe’ll have a joyous singing there, eternally(eternally).\n" +
                    "\n" +

                    "When my soul, will be caught up, to meet the Lord,\n" +
                    "Then beyond the pearly gates, being one of them\n" +
                    "(being one of them)\n" +
                    "With the whole eternity, behold the throne,\n" +
                    "Seeing my Lord Jesus Christ, in that heavenly home.\n" +
                    "(that heavenly home).\n" +
                    "\n" +

                    "Lord let me hear and obey, Thy word before you come,\n" +
                    "(You come for me)\n" +
                    "Let my life show everyone that I follow you\n" +
                    "(I follow you)\n" +
                    "Let faithful hearers come to thee,  before it’s late\n" +
                    "So wonderful when over comers, meet round the throne.\n" ),


    };

    public PresentTense(String present_title, String present_words) {
        this.present_title = present_title;
        this.present_words = present_words;
    }

    public String getPresent_title() {
        return present_title;
    }

    public String getPresent_words() {
        return present_words;
    }
    public String toString(){
        return this.present_title;
    }
}